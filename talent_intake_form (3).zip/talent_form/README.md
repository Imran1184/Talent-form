# Talent Intake Form

A simple working website with a 10-field form (name, contact, country, skill/position,
hourly rate, resume upload, availability, referral email). Submissions and uploaded
resumes are stored on the server — no third-party service required.

## What's included
- `app.py` — the whole backend (Flask). Handles the form, saves data to a local
  database file, saves uploaded resumes to a folder.
- `templates/` — the pages (form, thank-you page, admin view).
- `static/style.css` — styling.
- `submissions.db` — created automatically the first time you run the app. This is
  where every submission is stored (a small file-based database, no separate database
  server needed).
- `uploads/` — where uploaded resumes are saved.

## Run it on your own computer first (2 minutes)
1. Make sure Python 3 is installed.
2. Open a terminal in this folder and run:
   ```
   pip install -r requirements.txt
   python app.py
   ```
3. Open `http://localhost:5000` in your browser — the form is live.
4. To see submissions, go to `http://localhost:5000/admin/submissions?token=letmein`
   (change this token before going live — see "Before you go live" below).

## Putting it on your domain
This needs actual hosting (a server that stays running), not just uploading files to
your domain's file storage. The two easiest options:

### Option A — a beginner-friendly host (recommended)
Services like **Render**, **Railway**, or **PythonAnywhere** let you deploy this in
about 10 minutes without managing a server yourself:
1. Create a free account on one of these.
2. Connect your code (they'll ask you to upload it or link a GitHub repo).
3. They auto-detect it's a Flask app using `requirements.txt` and run it with:
   ```
   gunicorn app:app
   ```
4. Once deployed, they give you a URL. In your domain's DNS settings, add a CNAME
   record pointing your domain (or a subdomain like `apply.yourdomain.com`) to that URL.
   Each host has a short guide for "connecting a custom domain" — follow theirs exactly.

### Option B — your own VPS (more control, more setup)
If you already have server hosting (DigitalOcean, AWS EC2, etc.), upload this folder,
install `requirements.txt`, and run it behind a process manager (e.g. `gunicorn` +
`nginx`) so it stays running and is reachable on port 80/443 for your domain.

## Before you go live — a few important things to change
1. **Set a real secret key and admin token.** Right now they default to placeholder
   values in `app.py`. Set them as environment variables instead:
   ```
   export SECRET_KEY="something-long-and-random"
   export ADMIN_TOKEN="something-only-you-know"
   ```
   Your hosting provider will have a place to set these ("Environment Variables" in
   their dashboard) so they aren't stored in your code.
2. **Back up `submissions.db` and `uploads/` regularly** — that's where all your data
   lives. If your host offers persistent storage/volumes, make sure this folder is on
   one (some free hosting tiers wipe the filesystem on redeploy).
3. **Add HTTPS.** Most hosts (Render, Railway) give you this automatically once your
   domain is connected. Don't collect resumes/personal info over plain HTTP.
4. **The admin page is only protected by a token in the URL** — fine to get started,
   but if this will hold real applicant data long-term, consider adding a proper
   login later.

## Fields collected
First name, last name, email, phone number, country, skill or position, hourly rate,
resume (PDF or Word — .pdf, .doc, .docx, up to 10MB), availability in days, and an
optional referral email.
