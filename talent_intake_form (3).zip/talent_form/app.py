import os
import sqlite3
import uuid
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, flash, send_from_directory, g

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_FOLDER = os.path.join(BASE_DIR, "uploads")
DB_PATH = os.path.join(BASE_DIR, "submissions.db")
ALLOWED_EXTENSIONS = {"pdf", "doc", "docx"}
MAX_CONTENT_LENGTH = 10 * 1024 * 1024  # 10 MB cap on uploads

os.makedirs(UPLOAD_FOLDER, exist_ok=True)

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "change-this-secret-in-production")
app.config["MAX_CONTENT_LENGTH"] = MAX_CONTENT_LENGTH
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

COUNTRIES = [
    "United States", "India", "United Kingdom", "Canada", "Australia", "Germany",
    "France", "Philippines", "Pakistan", "Bangladesh", "Nigeria", "South Africa",
    "Brazil", "Mexico", "United Arab Emirates", "Singapore", "Other",
]


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(exception=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS submissions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            first_name TEXT NOT NULL,
            last_name TEXT NOT NULL,
            email TEXT NOT NULL,
            phone_number TEXT NOT NULL,
            country TEXT NOT NULL,
            skill_or_position TEXT NOT NULL,
            hourly_rate TEXT NOT NULL,
            resume_filename TEXT,
            resume_original_name TEXT,
            available_in_days TEXT NOT NULL,
            referral_email TEXT,
            consent_given TEXT NOT NULL,
            submitted_at TEXT NOT NULL
        )
        """
    )
    conn.commit()
    conn.close()


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


@app.route("/", methods=["GET"])
def index():
    return render_template("index.html", countries=COUNTRIES)


@app.route("/submit", methods=["POST"])
def submit():
    required_fields = [
        "first_name", "last_name", "email", "phone_number",
        "country", "skill_or_position", "hourly_rate", "available_in_days",
    ]
    data = {field: request.form.get(field, "").strip() for field in required_fields}
    referral_email = request.form.get("referral_email", "").strip()

    missing = [f for f in required_fields if not data[f]]

    consent_given = request.form.get("consent") == "yes"
    if not consent_given:
        flash("You must agree to the data-sharing consent to submit.", "error")
        return redirect(url_for("index"))

    resume_file = request.files.get("resume")
    resume_filename = None
    resume_original_name = None

    if not resume_file or resume_file.filename == "":
        missing.append("resume")
    elif not allowed_file(resume_file.filename):
        flash("Resume must be a PDF or Word document (.pdf, .doc, .docx).", "error")
        return redirect(url_for("index"))

    if missing:
        flash("Please fill in all required fields and attach your resume.", "error")
        return redirect(url_for("index"))

    ext = resume_file.filename.rsplit(".", 1)[1].lower()
    resume_original_name = resume_file.filename
    resume_filename = f"{uuid.uuid4().hex}.{ext}"
    resume_file.save(os.path.join(app.config["UPLOAD_FOLDER"], resume_filename))

    db = get_db()
    db.execute(
        """
        INSERT INTO submissions (
            first_name, last_name, email, phone_number, country,
            skill_or_position, hourly_rate, resume_filename, resume_original_name,
            available_in_days, referral_email, consent_given, submitted_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            data["first_name"], data["last_name"], data["email"], data["phone_number"],
            data["country"], data["skill_or_position"], data["hourly_rate"],
            resume_filename, resume_original_name, data["available_in_days"],
            referral_email, "yes", datetime.utcnow().isoformat(),
        ),
    )
    db.commit()

    return redirect(url_for("thank_you"))


@app.route("/thank-you")
def thank_you():
    return render_template("thank_you.html")


# --- Simple admin view to see submissions. Protect or remove before going fully public. ---
@app.route("/admin/submissions")
def admin_submissions():
    token = request.args.get("token", "")
    expected = os.environ.get("ADMIN_TOKEN", "letmein")
    if token != expected:
        return "Not authorized. Append ?token=YOUR_ADMIN_TOKEN to the URL.", 401

    db = get_db()
    rows = db.execute("SELECT * FROM submissions ORDER BY id DESC").fetchall()
    return render_template("admin.html", rows=rows, token=token)


@app.route("/admin/resume/<filename>")
def admin_resume(filename):
    token = request.args.get("token", "")
    expected = os.environ.get("ADMIN_TOKEN", "letmein")
    if token != expected:
        return "Not authorized.", 401
    return send_from_directory(app.config["UPLOAD_FOLDER"], filename, as_attachment=True)


if __name__ == "__main__":
    init_db()
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=True)
else:
    init_db()
